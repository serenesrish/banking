package com.banking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "beneficiary")
public class Beneficiary {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer beneficiaryId;
    private String beneficiaryName;
    private String beneficiaryAccountNumber;
    private String beneficiaryIFSC;
    private String nickName;

    public Beneficiary() {
	super();
    }

    public Integer getBeneficiaryId() {
	return beneficiaryId;
    }

    public void setBeneficiaryId(Integer beneficiaryId) {
	this.beneficiaryId = beneficiaryId;
    }

    public String getBeneficiaryName() {
	return beneficiaryName;
    }

    public void setBeneficiaryName(String beneficiaryName) {
	this.beneficiaryName = beneficiaryName;
    }

    public String getBeneficiaryAccountNumber() {
	return beneficiaryAccountNumber;
    }

    public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) {
	this.beneficiaryAccountNumber = beneficiaryAccountNumber;
    }

    public String getNickName() {
	return nickName;
    }

    public void setNickName(String nickName) {
	this.nickName = nickName;
    }

    public String getBeneficiaryIFSC() {
	return beneficiaryIFSC;
    }

    public void setBeneficiaryIFSC(String beneficiaryIFSC) {
	this.beneficiaryIFSC = beneficiaryIFSC;
    }

    public Beneficiary(Integer beneficiaryId, String beneficiaryName, String beneficiaryAccountNumber,
	    String beneficiaryIFSC, String nickName) {
	super();
	this.beneficiaryId = beneficiaryId;
	this.beneficiaryName = beneficiaryName;
	this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	this.beneficiaryIFSC = beneficiaryIFSC;
	this.nickName = nickName;
    }

    @Override
    public String toString() {
	return "Beneficiary [beneficiaryId=" + beneficiaryId + ", beneficiaryName=" + beneficiaryName
		+ ", beneficiaryAccountNumber=" + beneficiaryAccountNumber + ", beneficiaryIFSC=" + beneficiaryIFSC
		+ ", nickName=" + nickName + "]";
    }

}

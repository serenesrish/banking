package com.banking.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AuthorizedUser implements Serializable {// pojo for registered user
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int userId;
    private String firstName;
    private String lastName;
    private int phoneNumber;
    private String userEmail;
    private String Gender;
    private String password;
    /*
     * @Transient private String Account;
     * 
     * @OneToMany(cascade = CascadeType.ALL, mappedBy = "userdetails") // change the
     * userdetails code here private List<Account> Accounts = new
     * ArrayList<Account>();
     */

    /*
     * @OneToOne private AuthorizationDetails authorizationdetails; // object of
     * authorization details
     * 
     * public AuthorizationDetails getAuthorizationdetails() { return
     * authorizationdetails; }
     * 
     * public void setAuthorizationdetails(AuthorizationDetails
     * authorizationdetails) { this.authorizationdetails = authorizationdetails; }
     */
    public AuthorizedUser() {
	super();
    }

    public AuthorizedUser(String firstName, String lastName, int phoneNumber, String userEmail, String gender) {
	super();
	// this.userId = userId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.phoneNumber = phoneNumber;
	this.userEmail = userEmail;
	Gender = gender;
	// this.authorizationdetails = authorizationdetails;
	this.password = password;
    }

    public int getUserId() {
	return userId;
    }

    public void setUserId(int userId) {
	this.userId = userId;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public int getPhoneNumber() {
	return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
	this.phoneNumber = phoneNumber;
    }

    public String getUserEmail() {
	return userEmail;
    }

    public void setUserEmail(String userEmail) {
	this.userEmail = userEmail;
    }

    public String getGender() {
	return Gender;
    }

    public void setGender(String gender) {
	Gender = gender;
    }

    public String getPassword() {
	return password;
    }

    public void setPassword(String password) {
	this.password = password;
    }

    @Override
    public String toString() {
	return "AuthorizedUser [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName
		+ ", phoneNumber=" + phoneNumber + ", userEmail=" + userEmail + ", Gender=" + Gender + ", password="
		+ password + "]";
    }

}

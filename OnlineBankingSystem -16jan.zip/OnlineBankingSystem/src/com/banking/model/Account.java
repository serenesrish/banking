package com.banking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    private Integer Id;

    // Account Balance
    private String accountName;

    private long accountBalance;

    public Account() {
	super();
    }

    public String getAccountName() {
	return accountName;
    }

    public void setAccountName(String accountName) {
	this.accountName = accountName;
    }

    public long getAccountBalance() {
	return accountBalance;
    }

    public void setAccountBalance(long accountBalance) {
	this.accountBalance = accountBalance;
    }

    public Account(Integer accountId, String accountName, long accountBalance) {
	super();
	this.Id = Id;
	this.accountName = accountName;
	this.accountBalance = accountBalance;
    }

    @Override
    public String toString() {
	return "Account [Id=" + Id + ", accountName=" + accountName + ", accountBalance=" + accountBalance + "]";
    }

}
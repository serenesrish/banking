package com.banking.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.banking.model.Account;

@Repository
public class AccountDaoImpl implements IAccountDao {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getCurrentSession() {
	return sessionFactory.getCurrentSession();
    }

    public void addAccount(Account account) {
	getCurrentSession().save(account);
    }

    public Account getAccountDetails(long id) {
	Account account = (Account) getCurrentSession().get(Account.class, id);
	return account;
    }

    @Override
    public void updateAccount(Account account) {
	getCurrentSession().update(account);

    }
}

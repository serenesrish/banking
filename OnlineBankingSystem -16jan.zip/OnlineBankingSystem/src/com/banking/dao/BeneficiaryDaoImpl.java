package com.banking.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.banking.model.Beneficiary;

@Repository
public class BeneficiaryDaoImpl implements IBeneficiaryDao {

    static Transaction tcx;
    private SessionFactory sessionFactory;

    @Autowired
    public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
    }

    @Override
    public void addBeneficiary(Beneficiary b) {
	Session session = this.sessionFactory.openSession();
	tcx = session.beginTransaction();
	System.out.println(b);
	session.save(b);
	tcx.commit();
	session.close();

    }

    @Override
    public Beneficiary getBeneficiaryById(int id) {
	// TODO Auto-generated method stub
	Session session = this.sessionFactory.openSession();
	tcx = session.beginTransaction();
	Beneficiary b = (Beneficiary) session.load(Beneficiary.class, new Integer(id));
	System.out.println(b);
	session.save(b);
	tcx.commit();
	session.close();
	return b;
    }

}

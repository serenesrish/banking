package com.banking.dao;

import com.banking.model.Beneficiary;

public interface IBeneficiaryDao {

    public void addBeneficiary(Beneficiary b);

    public Beneficiary getBeneficiaryById(int id);

}

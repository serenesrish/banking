package com.banking.dao;

import com.banking.model.Account;

public interface IAccountDao {

    public void addAccount(Account account);

    public Account getAccountDetails(long accountId);

    public void updateAccount(Account account);

}
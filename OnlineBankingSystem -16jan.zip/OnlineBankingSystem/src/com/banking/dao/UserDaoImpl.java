package com.banking.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.banking.model.AuthorizedUser;

@Repository
public class UserDaoImpl implements IUserDao {
    static Transaction tcx;
    private SessionFactory sessionFactory;

    @Autowired
    public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
    }

    @Override
    public List fetchPassword(String userEmail) {
	Session session = this.sessionFactory.openSession();
	tcx = session.beginTransaction();
	Query q = session.createQuery("from AuthorizedUser where userEmail=:userEmail");
	q.setString("userEmail", userEmail);
	List l = q.list();
	l.get(6);
	tcx.commit();
	session.close();
	return l;

    }

    @Override
    public void AddUser(AuthorizedUser authuser) {

	Session session = this.sessionFactory.openSession();
	tcx = session.beginTransaction();
	System.out.println(authuser);
	session.save(authuser);
	tcx.commit();
	session.close();

    }

    @Override
    public boolean verifyUser(String username, String password) {
	Session session = this.sessionFactory.openSession();

	String query = "From AuthorizedUser a where a.userEmail=:username and a.password=:password";

	Query q = session.createQuery(query);
	q.setString("username", username);
	q.setString("password", password);
	List<AuthorizedUser> l = q.list();

	if (l.size() == 0) {
	    return false;
	}
	session.close();
	return true;

    }
}
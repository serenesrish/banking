package com.banking.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.banking.model.Account;
import com.banking.model.AuthorizedUser;
import com.banking.model.Beneficiary;
import com.banking.service.IAccountService;
import com.banking.service.IBeneficiaryService;
import com.banking.service.IUserService;

/**
 * @author vshadmin
 *
 */
@Controller
public class BankController {
    @Autowired
    IUserService userService;
    @Autowired
    private IAccountService accountService;

    @Autowired
    private IBeneficiaryService beneficiaryService;

    public void setAccountService(IAccountService accountService) {
	this.accountService = accountService;
    }

    public void setBeneficiaryService(IBeneficiaryService beneficiaryService) {
	this.beneficiaryService = beneficiaryService;
    }

    public void setUserService(IUserService userService) {
	this.userService = userService;
    }

    @RequestMapping("/LoginView")
    public String showLoginView(Model model) {
	model.addAttribute("authuser", new AuthorizedUser());
	String view = "LoginView";

	return view;
    }

    /*
     * @RequestMapping("/registerPage") public String registerView(Model model) {
     * model.addAttribute("authuser", new AuthorizedUser()); String view =
     * "successPage";
     * 
     * AuthorizedUser authuser = null; this.userService.AddUser(authuser);
     * 
     * return view; }
     */

    @RequestMapping(value = "/registerPage", method = RequestMethod.POST)
    public String validateregistrationPage(@Valid @ModelAttribute("authuser") AuthorizedUser authuser,
	    BindingResult bindingResult, Model model, HttpServletRequest req) {

	String view = "";
	if (bindingResult.hasErrors()) {
	    view = "successPage";
	    return view;
	} else {
	    String username = req.getParameter("userEmail");
	    String password = req.getParameter("password");

	    /*
	     * System.out.println(username); System.out.println(password);
	     * System.out.println(authuser);
	     */
	    userService.AddUser(authuser);

	    view = "successPage";
	    return view;

	}
    }

    @RequestMapping(value = "/LoginVerification", method = RequestMethod.POST)
    public String LoginValidation(Model model, HttpServletRequest req) {
	String username = req.getParameter("username");
	String password = req.getParameter("password");

	System.out.println("this is password" + password);
	if (userService.verifyUser(username, password)) {
	    return "successPage";
	}
	return "LoginView";

    }

    @RequestMapping("/logout")
    public String logout(HttpSession session) {
	session.invalidate();
	return "LoginView";
    }

    /*
     * @RequestMapping(value = "/logout", method = RequestMethod.GET) public String
     * logout(HttpSession session) { session.removeAttribute("username"); return
     * "redirect:../LoginView"; }
     */

    /*
     * @RequestMapping(value = "/addAccount", method = RequestMethod.POST) public
     * ModelAndView addAccount(@ModelAttribute Account account) {
     * 
     * ModelAndView modelAndView = new ModelAndView("account");
     * accountService.addAccount(account);
     * 
     * String view = "successPage"; modelAndView.addObject("message", message);
     * 
     * return modelAndView;
     * 
     * }
     */

    @RequestMapping("/addAccount")
    public String addAccount(Model model) {
	model.addAttribute("account", new Account());
	String view = "account";

	return view;
    }

    @RequestMapping(value = "/get/{beneficiaryId}", method = RequestMethod.GET)
    public ModelAndView getBeneficiary(@PathVariable Integer beneficiaryId) {
	ModelAndView modelAndView = new ModelAndView("account");

	Beneficiary beneficiary = beneficiaryService.getBeneficiaryById(beneficiaryId);
	modelAndView.addObject("beneficiary", beneficiary);

	return modelAndView;
    }

    @RequestMapping("/addBeneficiary")
    public String showBeneficiary(Model model) {
	model.addAttribute("b", new Beneficiary());
	String view = "addBeneficiary";

	return view;
    }

    @RequestMapping(value = "/regPage", method = RequestMethod.POST)
    public String addBenDet(@Valid @ModelAttribute("beneficiary") Beneficiary beneficiary, Model model,
	    HttpServletRequest req) {

	String view = " ";

	/*
	 * System.out.println(username); System.out.println(password);
	 * System.out.println(authuser);
	 */
	beneficiaryService.addBeneficiary(beneficiary);
	view = "successPage";
	return view;

    }
}

package com.banking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.model.AuthorizedUser;

@Service
public interface IUserService {
    List fetchPassword(String email);

    public void AddUser(AuthorizedUser authuser);

    boolean verifyUser(String username, String password);
}

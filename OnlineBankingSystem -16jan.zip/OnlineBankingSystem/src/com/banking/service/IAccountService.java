package com.banking.service;

import com.banking.model.Account;

public interface IAccountService {

    public void addAccount(Account account);

    public Account getAccountDetails(long accountId);

    public String depositAmount(long fromAccountId, long toAccountId, long amountToTransfer, String transferType);

    public String withdrawAmount(long accountId, long amountTowithdraw);

}

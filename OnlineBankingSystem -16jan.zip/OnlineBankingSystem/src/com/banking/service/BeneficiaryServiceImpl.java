package com.banking.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.banking.dao.IBeneficiaryDao;
import com.banking.model.Beneficiary;

@Service
@Transactional

public class BeneficiaryServiceImpl implements IBeneficiaryService {

    private IBeneficiaryDao beneficiaryDao;

    @Override
    public void addBeneficiary(Beneficiary b) {
	// TODO Auto-generated method stub
	this.beneficiaryDao.addBeneficiary(b);
    }

    @Override
    public Beneficiary getBeneficiaryById(int id) {
	// TODO Auto-generated method stub
	return this.beneficiaryDao.getBeneficiaryById(id);
    }

}
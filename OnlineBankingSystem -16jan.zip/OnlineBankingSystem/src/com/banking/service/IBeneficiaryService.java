package com.banking.service;

import com.banking.model.Beneficiary;

public interface IBeneficiaryService {

    public void addBeneficiary(Beneficiary b);

    public Beneficiary getBeneficiaryById(int id);

}
